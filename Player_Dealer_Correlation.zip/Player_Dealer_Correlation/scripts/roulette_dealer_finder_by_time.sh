#!binbash

awk -F" " '$1 = /12:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /01:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /02:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /03:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /04:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /05:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /06:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /07:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /08:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /09:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /10:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /11:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /12:00:00 AM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /01:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /02:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /03:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /04:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /05:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /06:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /07:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /08:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /09:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /10:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
awk -F" " '$1 = /11:00:00 PM/ {print $1, $2, $5, $6}' $2_Dealer_schedule
