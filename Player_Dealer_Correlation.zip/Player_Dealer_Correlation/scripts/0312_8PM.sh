#!bin/bash

awk -F" " '/08:00:00 PM/ {print $1, $2, $5, $6}' 0312_Dealer_schedule  >> Dealers_working_during_losses
